//pub mod all files in the models folder here
pub mod asteroid;
pub mod page;
pub mod user;

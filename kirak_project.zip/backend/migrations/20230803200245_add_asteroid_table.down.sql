-- Add down migration script here
DROP table asteroids;
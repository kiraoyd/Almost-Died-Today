use reqwest::Client;

#[tokio::main]
async fn main() -> anyhow::Result<()>{
    let client = Client::new(); //make the new client instance

    //CODE HERE

    Ok(())
}